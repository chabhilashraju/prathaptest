import { Injectable } from '@angular/core';
import { Todo } from '../model/todo';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable()
export class TodoService {

    public todos: Todo[] = [];
    constructor(private http: HttpClient) { }

    todoApi = 'api/todoArrayData';


    getTodoData(): Observable<Todo[]> {
        return this.http.get<Todo[]>(this.todoApi);
    }


    getAllTodos(): Todo[] {

        if (sessionStorage.getItem('localSessionTodoData') !== null) {
            this.todos = JSON.parse(sessionStorage.getItem('localSessionTodoData'));
            console.log('Second');
        }
        return this.todos;
    }

    getTodoById(id: number): Todo {
        var todoArray = JSON.parse(sessionStorage.getItem('localSessionTodoData'));
        console.log(todoArray);
        return todoArray
            .filter(todo => todo.id === id)
            .pop();
    }

    updateTodoById(todo): Todo {
        if (todo.id === 0) {
            var todoArray = JSON.parse(sessionStorage.getItem('localSessionTodoData'));
            var todoid = todoArray.length;
            todo.id = ++todoid;
            todoArray.push(todo);
            sessionStorage.setItem('localSessionTodoData', JSON.stringify(todoArray));
        } else {
            var todoSaveArray = JSON.parse(sessionStorage.getItem('localSessionTodoData'));
            for (var i in todoSaveArray) {
                if (todoSaveArray[i].id === todo.id) {
                    todoSaveArray[i] = todo;
                    sessionStorage.setItem('localSessionTodoData', JSON.stringify(todoSaveArray));
                }
            }
        }
        return todo;
    }

    deleteTodoDetail(id) {
        var todoArray = JSON.parse(sessionStorage.getItem('localSessionTodoData'));
        for (var i in todoArray) {
            if (todoArray[i].id === id) {
                todoArray.splice(i, 1);
                sessionStorage.setItem('localSessionTodoData', JSON.stringify(todoArray));
            }
        }
    };
}
