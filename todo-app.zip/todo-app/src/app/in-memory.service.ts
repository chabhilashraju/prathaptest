import { InMemoryDbService } from 'angular-in-memory-web-api';

export class InMemoryService implements InMemoryDbService {
  createDb() {
    const todoArrayData = [
      {
        id: 1,
        taskName: 'Sample Task 1',
        name: 'Test Name 1',
        date: '10/18/2019',
        phone: '1234567890',
        email: 'test1@gmail.com'
      },
      {
        id: 2,
        taskName: 'Sample Task 2',
        name: 'Test Name 2',
        date: '10/19/2019',
        phone: '0987654321',
        email: 'test2@gmail.com'
      },
      {
        id: 3,
        taskName: 'Sample Task 3',
        name: 'Test Name 3',
        date: '10/20/2019',
        phone: '1234554321',
        email: 'test3@gmail.com'
      }
      ,
      {
        id: 4,
        taskName: 'Sample Task 4',
        name: 'Test Name 4',
        date: '10/21/2019',
        phone: '1122334455',
        email: 'test4@gmail.com'
      }
    ];
    return { todoArrayData };
  }
}